from sqlalchemy import Column, Text, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import String as SQLString
import uuid
from ..database import Base, engine

# UUID handling
if engine.dialect.name == 'postgresql':
    UUIDType = UUID(as_uuid=True)
else:
    UUIDType = SQLString(36)


class Story(Base):
    __tablename__ = "stories"

    story_id = Column(UUIDType, primary_key=True, default=uuid.uuid4)
    title = Column(Text, nullable=False)
    meta_title = Column(Text)
    thumbnail_square = Column(Text)
    thumbnail_rect = Column(Text)
    thumbnail_responsive = Column(Text)
    description = Column(Text)
    meta_description = Column(Text)
    genre = Column(Text)
    rating = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    episodes = relationship("Episode", back_populates="story", cascade="all, delete-orphan")
    comments = relationship("Comment", back_populates="story", cascade="all, delete-orphan")
    likes = relationship("Like", back_populates="story", cascade="all, delete-orphan")
    ratings = relationship("Rating", back_populates="story", cascade="all, delete-orphan")
    views = relationship("View", back_populates="story", cascade="all, delete-orphan")
    home_content_series = relationship("HomeContentSeries", back_populates="story", cascade="all, delete-orphan")
    slideshows = relationship("HomeSlideshow", back_populates="story", cascade="all, delete-orphan")
    home_continue_watching = relationship("HomeContinueWatching", back_populates="story", cascade="all, delete-orphan")
