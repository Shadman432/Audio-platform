from sqlalchemy import Column, Text, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import String as SQLString
import uuid
from ..database import Base, engine

# Use appropriate UUID type based on database
if engine.dialect.name == 'postgresql':
    UUIDType = UUID(as_uuid=True)
else:
    UUIDType = SQLString(36)

class HomeContent(Base):
    __tablename__ = "home_content"
    
    categoryid = Column(UUIDType, primary_key=True, default=uuid.uuid4)
    category_name = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # ✅ Relationships with stories (via HomeContentSeries)
    home_content_series = relationship(
        "HomeContentSeries",
        back_populates="home_content",
        cascade="all, delete-orphan"
    )
