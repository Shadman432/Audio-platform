from sqlalchemy import Column, DateTime, ForeignKey, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import String as SQLString
import uuid
from ..database import Base, engine

# Use appropriate UUID type based on database
if engine.dialect.name == 'postgresql':
    UUIDType = UUID(as_uuid=True)
else:
    UUIDType = SQLString(36)


class HomeSlideshow(Base):
    __tablename__ = "home_slideshow"
    
    slideshow_id = Column(UUIDType, primary_key=True, default=uuid.uuid4)
    story_id = Column(UUIDType, ForeignKey("stories.story_id", ondelete="CASCADE"), nullable=False)

    # 👉 Duplicate Story fields (denormalized for faster API response)
    title = Column(Text, nullable=True)
    description = Column(Text, nullable=True)
    genre = Column(Text, nullable=True)
    rating = Column(Text, nullable=True)
    thumbnail_square = Column(Text, nullable=True)
    thumbnail_rect = Column(Text, nullable=True)
    thumbnail_responsive = Column(Text, nullable=True)
    backdrop_url = Column(Text, nullable=True)
    trailer_url = Column(Text, nullable=True)

    # Slideshow specific fields
    display_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # ✅ Relationship with Story
    story = relationship("Story", back_populates="slideshows")
